sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ztchcnf01.conf01.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);