sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("ztchcnf01.conf01.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map